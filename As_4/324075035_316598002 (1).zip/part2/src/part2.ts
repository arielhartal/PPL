// PPL 2023 HW4 Part2

// Q 2.1 

// Specify the return type.
export const delayedSum = (a: number, b: number, delay: number): Promise<number> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(a + b);
        }, delay);
    });
}

export const testDelayedSum = () : Promise<Boolean> => {
    const a = 5;
    const b = 10;
    const delay = 2000; // 2 seconds

    const startTime = Date.now();

    return new Promise((resolve, reject) => {
        delayedSum(a, b, delay)
          .then(() => {
            const endTime = Date.now();
            const duration = endTime - startTime;
    
            if (duration >= delay) {
              resolve(true); // in case the test passed
            } else {
              reject(false); // in case the test failed
            }
          })
          .catch((error) => { // other type of message
            console.error(error);
            reject(error);
          });
    });
    
};


 

// Q 2.2

// Values returned by API calls.
export type Post = {
    userId: number;
    id: number;
    title: string;
    body: string;
}

// When invoking fetchData(postsUrl) you obtain an Array Post[]
// To obtain an array of posts
export const postsUrl = 'https://jsonplaceholder.typicode.com/posts'; 

// Append the desired post id.
export const postUrl = 'https://jsonplaceholder.typicode.com/posts/'; 

// When invoking fetchData(invalidUrl) you obtain an error
export const invalidUrl = 'https://jsonplaceholder.typicode.com/invalid';

// Depending on the url - fetchData can return either an array of Post[] or a single Post.
// Specify the return type without using any.
export const fetchData = async (url: string): Promise<Post | Post[]> => {
    const response = await fetch(url);

    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
   // return data;

    if (Array.isArray(data)) {
        // If data is an array, we assume it's an array of Post objects
        return data as Post[];
    } else {
        // If data is not an array, we assume it's a single Post object
        return data as Post;
    }
};


export const testFetchData = async (check: string) : Promise<string> => {
    try {
        switch(check) {
            case 'one':
                const id = 1;
                const id_posts = `${postUrl}${id}`;
                const post = await fetchData(id_posts);
                return Promise.resolve('Success with single post result');
            case 'array':
                const posts = await fetchData(postsUrl);
                return Promise.resolve('Success with array result');
            case 'error':
                await fetchData(invalidUrl);
                break;
            
            default:
                throw new Error('Invalid scenario provided');

        }

    } catch (error: any){
        return Promise.resolve('Failed call');
    }

    return Promise.resolve('Default');
};



// Q 2.3

// Specify the return type.
export const fetchMultipleUrls = async (urls: string[]): Promise<any[]> => {
    const promises = urls.map(url => fetchData(url));
    return await Promise.all(promises);
};

export const testFetchMultipleUrls = async (): Promise<boolean[]> => {
    const urls = Array.from({ length: 20 }, (_, i) => postUrl + (i + 1));
    return new Promise<boolean[]>(async (resolve) => {
      try {
        const results: boolean[] = [];
  
        // Test Case 1: Successful call to fetchMultipleUrls
        await fetchMultipleUrls(urls);
        results.push(true);
  
        // Test Case 2: Successful call to fetchMultipleUrls - Verify results are in the expected order
        const responseData = await fetchMultipleUrls(urls);
        const expectedOrder = urls.map((url) => url.substring(url.lastIndexOf('/') + 1));
        const actualOrder = responseData.map((data) => data.id.toString());
        if (JSON.stringify(actualOrder) === JSON.stringify(expectedOrder)) {
          results.push(true);
        } else {
          results.push(false);
        }
  
        // Test Case 3: Failed call to fetchMultipleUrls
        const invalidUrls = [...urls, 'invalid-url'];
        try {
          await fetchMultipleUrls(invalidUrls);
          results.push(false);
        } catch (error) {
          results.push(true);
        }
  
        resolve(results);
      } catch (error) {
        resolve([]);
      }
    });
    
};