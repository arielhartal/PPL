import { describe, expect, test } from '@jest/globals'
import {
    delayedSum, Post, postsUrl, postUrl, invalidUrl, fetchData, fetchMultipleUrls, testDelayedSum, testFetchData, testFetchMultipleUrls
} from '../src/part2';

describe('Assignment 4 Part 2', () => {
    describe('Q2.1 delayedSum (6 points)', () => {
        test('delayedSum returns the sum', () => {
            const a = 5;
            const b = 10;
            const delay = 2000;
            
            return delayedSum(a, b, delay).then((result) => {
                expect(result).toBe(a + b);
              });
            });
        
            test('delayedSum waits at least the specified delay', () => {
              return testDelayedSum().then((result) => {expect(result).toBe(true);})
            });
    })

    describe('Q2.2 fetchData (12 points)', () => {
        test('successful call to fetchData with array result', async () => {
            const result = await testFetchData('array');
            expect(result).toBe('Success with array result');
          });
        
          test('successful call to fetchData with Post result', async () => {
            const result = await testFetchData('one');
            expect(result).toBe('Success with single post result');
          });
        
          test('failed call to fetchData', async () => {
            const result = await testFetchData('error');
            expect(result).toBe('Failed call');
          });
        });

    
    
    

    describe('Q2.3 fetchMultipleUrls (12 points)', () => {
        test('successful call to fetchMultipleUrls', async () => {
            const results = await testFetchMultipleUrls();
            expect(results[0]).toBe(true);
        });

        test('successful call to fetchMultipleUrls: verify results are in the expected order ', async () => {
            const results = await testFetchMultipleUrls();
            expect(results[1]).toBe(true);
        });

        test('failed call to fetchMultipleUrls', async () => {
            const results = await testFetchMultipleUrls();
            expect(results[2]).toBe(true);
        });
    });
});

