import { isTypedArray } from 'util/types';
import { Exp, isProgram, makeBoolExp, makeIfExp, makeNumExp, makeProcExp, makeStrExp, makeVarDecl, parseL5, parseL5Exp, Program, unparse } from '../src/L5/L5-ast';
import { typeofProgram, L5typeof, checkCompatibleType, makeUnion, typeofIf } from '../src/L5/L5-typecheck';
import { applyTEnv, makeEmptyTEnv } from '../src/L5/TEnv';
import { isNumTExp, isProcTExp, makeBoolTExp, makeNumTExp, makeProcTExp, makeTVar, 
         makeVoidTExp, parseTE, unparseTExp, TExp, isTExp, makeStrTExp, makeUnionTExp } from '../src/L5/TExp';
import { makeOk, isOkT, bind, mapv, isFailure, Result, makeFailure, isOk } from '../src/shared/result';
import { isError } from '../src/shared/type-predicates';

describe('L5 Type Checker', () => {
    describe('parseTE', () => {
        it('parses atoms', () => {
            expect(parseTE("number")).toEqual(makeOk(makeNumTExp()));
            expect(parseTE("boolean")).toEqual(makeOk(makeBoolTExp()));
        });

        it('parses type variables', () => {
            expect(parseTE("T1")).toEqual(makeOk(makeTVar("T1")));
        });

        it('parses procedures', () => {
            expect(parseTE("(number -> (number -> number))")).toEqual(
                makeOk(makeProcTExp([makeNumTExp()], makeProcTExp([makeNumTExp()], makeNumTExp())))
            );
        });

        it('parses "void" and "Empty"', () => {
            expect(parseTE("void")).toEqual(makeOk(makeVoidTExp()));
            expect(parseTE("(Empty -> void)")).toEqual(makeOk(makeProcTExp([], makeVoidTExp())));
        });
    });

    describe('unparseTExp', () => {
        it('unparses atoms', () => {
            expect(unparseTExp(makeNumTExp())).toEqual(makeOk("number"));
            expect(unparseTExp(makeBoolTExp())).toEqual(makeOk("boolean"));
        });

        it('unparses type variables', () => {
            expect(unparseTExp(makeTVar("T1"))).toEqual(makeOk("T1"));
        });

        it('unparses procedures', () => {
            expect(unparseTExp(makeProcTExp([makeTVar("T"), makeTVar("T")], makeBoolTExp()))).toEqual(makeOk("(T * T -> boolean)"));
            expect(unparseTExp(makeProcTExp([makeNumTExp()], makeProcTExp([makeNumTExp()], makeNumTExp())))).toEqual(makeOk("(number -> (number -> number))"));
        });
    });

    describe('L5typeof', () => {
        it('returns the types of atoms', () => {
            expect(L5typeof("5")).toEqual(makeOk("number"));
            expect(L5typeof("#t")).toEqual(makeOk("boolean"));
        });

        it('returns the type of primitive procedures', () => {
            expect(L5typeof("+")).toEqual(makeOk("(number * number -> number)"));
            expect(L5typeof("-")).toEqual(makeOk("(number * number -> number)"));
            expect(L5typeof("*")).toEqual(makeOk("(number * number -> number)"));
            expect(L5typeof("/")).toEqual(makeOk("(number * number -> number)"));
            expect(L5typeof("=")).toEqual(makeOk("(number * number -> boolean)"));
            expect(L5typeof("<")).toEqual(makeOk("(number * number -> boolean)"));
            expect(L5typeof(">")).toEqual(makeOk("(number * number -> boolean)"));
            expect(L5typeof("not")).toEqual(makeOk("(boolean -> boolean)"));
        });

        it("returns the type of primitive op applications", () => {
            expect(L5typeof("(+ 1 2)")).toEqual(makeOk("number"));
            expect(L5typeof("(- 1 2)")).toEqual(makeOk("number"));
            expect(L5typeof("(* 1 2)")).toEqual(makeOk("number"));
            expect(L5typeof("(/ 1 2)")).toEqual(makeOk("number"));

            expect(L5typeof("(= 1 2)")).toEqual(makeOk("boolean"));
            expect(L5typeof("(< 1 2)")).toEqual(makeOk("boolean"));
            expect(L5typeof("(> 1 2)")).toEqual(makeOk("boolean"));

            expect(L5typeof("(not (< 1 2))")).toEqual(makeOk("boolean"));
        });

        it.skip('type checking of generic functions is not supported', () => {
            // All of these fail in TypeCheck because we do not support generic functions
            // They do work in Type Inference.
            expect(L5typeof("(eq? 1 2)")).toEqual(makeOk("boolean"));
            expect(L5typeof('(string=? "a" "b")')).toEqual(makeOk("boolean"));
            expect(L5typeof('(number? 1)')).toEqual(makeOk("boolean"));
            expect(L5typeof('(boolean? "a")')).toEqual(makeOk("boolean"));
            expect(L5typeof('(string? "a")')).toEqual(makeOk("boolean"));
            expect(L5typeof('(symbol? "a")')).toEqual(makeOk("boolean"));
            expect(L5typeof('(list? "a")')).toEqual(makeOk("boolean"));
            expect(L5typeof('(pair? "a")')).toEqual(makeOk("boolean"));
        });

        it('returns the type of "if" expressions', () => {
            expect(L5typeof("(if (> 1 2) 1 2)")).toEqual(makeOk("number"));
            expect(L5typeof("(if (= 1 2) #t #f)")).toEqual(makeOk("boolean"));
        });

        it('returns the type of procedures', () => {
            expect(L5typeof("(lambda ((x : number)) : number x)")).toEqual(makeOk("(number -> number)"));
            expect(L5typeof("(lambda ((x : number)) : boolean (> x 1))")).toEqual(makeOk("(number -> boolean)"));
            expect(L5typeof("(lambda((x : number)) : (number -> number) (lambda((y : number)) : number (* y x)))")).toEqual(makeOk("(number -> (number -> number))"));
            expect(L5typeof("(lambda((f : (number -> number))) : number (f 2))")).toEqual(makeOk("((number -> number) -> number)"));
            expect(L5typeof("(lambda((x : number)) : number (let (((y : number) x)) (+ x y)))")).toEqual(makeOk("(number -> number)"));
        });

        it('returns the type of "let" expressions', () => {
            expect(L5typeof("(let (((x : number) 1)) (* x 2))")).toEqual(makeOk("number"));
            expect(L5typeof("(let (((x : number) 1) ((y : number) 3)) (+ x y))")).toEqual(makeOk("number"));
            expect(L5typeof("(let (((x : number) 1) ((y : number) 2)) (lambda((a : number)) : number (+ (* x a) y)))")).toEqual(makeOk("(number -> number)"));
        });

        it('returns the type of "letrec" expressions', () => {
            expect(L5typeof("(letrec (((p1 : (number -> number)) (lambda((x : number)) : number (* x x)))) p1)")).toEqual(makeOk("(number -> number)"));
            expect(L5typeof("(letrec (((p1 : (number -> number)) (lambda((x : number)) : number (* x x)))) (p1 2))")).toEqual(makeOk("number"));
            expect(L5typeof(`
                (letrec (((odd? : (number -> boolean)) (lambda((n : number)) : boolean (if (= n 0) #f (even? (- n 1)))))
                         ((even? : (number -> boolean)) (lambda((n : number)) : boolean (if (= n 0) #t (odd? (- n 1))))))
                  (odd? 12))`)).toEqual(makeOk("boolean"));
        });

        it('returns "void" as the type of "define" expressions', () => {
            expect(L5typeof("(define (foo : number) 5)")).toEqual(makeOk("void"));
            expect(L5typeof("(define (foo : (number * number -> number)) (lambda((x : number) (y : number)) : number (+ x y)))")).toEqual(makeOk("void"));
            expect(L5typeof("(define (x : (Empty -> number)) (lambda () : number 1))")).toEqual(makeOk("void"));
        });

        it.skip('returns "literal" as the type for literal expressions', () => {
            expect(L5typeof("(quote ())")).toEqual(makeOk("literal"));
        });
	});

    // TODO L51 Typecheck program with define
    describe('L5 Typecheck program with define', () => {
        it('should typecheck a program with define', () => {
            const program = "(L5 (define (a : string) abc)";
            expect(() => L5typeof(program)).not.toThrow();
        });
        
        
     
    });

    // TODO L51 Test checkCompatibleType with unions
    describe('L5 Test checkCompatibleType with unions', () => {
        it('checks compatibility with union types', () => {
        // Test: number is compatible with (union number boolean)
        expect(checkCompatibleType(makeNumTExp(), makeUnionTExp([makeNumTExp(), makeBoolTExp()]), makeNumExp(5))).toEqual(makeOk(true));

        // Test: boolean is not compatible with (union number string)
        expect(checkCompatibleType(makeBoolTExp(), makeUnionTExp([makeNumTExp(), makeStrTExp()]), makeBoolExp(true))).toEqual(makeFailure<true>("Incompatible types: boolean and (union number string) in #t"));

        // Test: (union number boolean) is compatible with (union number boolean string)
        expect(checkCompatibleType(makeUnionTExp([makeNumTExp(), makeBoolTExp()]), makeUnionTExp([makeNumTExp(), makeBoolTExp(), makeStrTExp()]), makeNumExp(5))).toEqual(makeOk(true));

        // Test: (union boolean string) is not compatible with (union number string)
        expect(checkCompatibleType(makeUnionTExp([makeBoolTExp(), makeStrTExp()]), makeUnionTExp([makeNumTExp(), makeStrTExp()]), makeStrExp("test"))).toEqual(makeFailure<true>("Incompatible types: (union boolean string) and (union number string) in \"test\""));
    });
    });

    // TODO L51 Test makeUnion
    describe('L5 Test makeUnion', () => {
        // makeUnion( number, boolean) -> union((number, boolean))
        it('should create union of number and boolean', () => {
            const result = makeUnion(makeNumTExp(), makeBoolTExp());
            expect(result).toEqual(makeUnionTExp([makeNumTExp(), makeBoolTExp()]));
        });
        // makeUnion( union(number, boolean), string) -> union(boolean, number, string)
        it('should create union of union(number, boolean) and string', () => {
            const result = makeUnion(makeUnionTExp([makeNumTExp(), makeBoolTExp()]), makeStrTExp());
            expect(result).toEqual(makeUnionTExp([makeNumTExp(), makeBoolTExp(), makeStrTExp()]));
        });
        // makeUnion( union(number, boolean), union(boolean, string)) -> union(boolean, number, string)
        it('should create union of union(number, boolean) and union(boolean, string)', () => {
            const result = makeUnion(makeUnionTExp([makeNumTExp(), makeBoolTExp()]), makeUnionTExp([makeBoolTExp(), makeStrTExp()]));
            expect(result).toEqual(makeUnionTExp([makeNumTExp(), makeBoolTExp(), makeStrTExp()]));
        });
        // makeUnion( number, union(number, boolean)) -> union(boolean, number)
        it('should create union of number and union(number, boolean)', () => {
            const result = makeUnion(makeNumTExp(), makeUnionTExp([makeNumTExp(), makeBoolTExp()]));
            expect(result).toEqual(makeUnionTExp([makeNumTExp(), makeBoolTExp()]));
        });
     
        // TODO L51
    });
    
    // TODO L51 Test typeOfIf with union in all relevant positions
    describe('L5 Test typeOfIf with union in all relevant positions', () => {
        const tenv = makeEmptyTEnv();
        // typeOfIf( (if #t 1 #t) ) -> union(boolean, number)
        it('should return union of boolean and number for (if #t 1 #t)', () => {
            const ifExp = makeIfExp(makeBoolExp(true), makeNumExp(1), makeBoolExp(true));
            const result = typeofIf(ifExp, tenv);
        
            if(isOk(result)) {
                const texp = result.value;
                if(texp.tag === "UnionTExp") {
                    expect(texp.components.length).toBe(2);
                    expect(texp.components.some(te => te.tag === "BoolTExp")).toBeTruthy();
                    expect(texp.components.some(te => te.tag === "NumTExp")).toBeTruthy();
                } else {
                    fail(`Expected UnionTExp but got ${texp.tag}`);
                }
            } else {
                fail(`Expected Ok but got Failure with message: ${result.message}`);
            }
        });
        
    
        // typeOfIf( (if #t 1 2) ) -> number
        it('should return number type for (if #t 1 2)', () => {
            const ifExp = makeIfExp(makeBoolExp(true), makeNumExp(1), makeNumExp(2));
            const result = typeofIf(ifExp, tenv);
            expect(result).toEqual(makeOk(makeNumTExp()));
        });
        // typeOfIf( (if #t (if #f 1 #t) "ok") ) -> union(boolean, number, string)
        it('should return union of number and string for (if #t 1 "ok")', () => {
            const ifExp = makeIfExp(makeBoolExp(true), makeNumExp(1), makeStrExp("ok"));
            const result = typeofIf(ifExp, tenv);
            expect(result).toEqual(makeOk(makeUnionTExp([makeNumTExp(), makeStrTExp()])));
        });
        // typeOfIf( (if 1 2 3) ) -> failure
        it('should return failure for (if 1 2 3)', () => {
            const ifExp = makeIfExp(makeNumExp(1), makeNumExp(2), makeNumExp(3));
            const result = typeofIf(ifExp, tenv);
            expect(result).toEqual(makeFailure("Incompatible types: number and boolean in (if 1 2 3)"));
        });
    });

    // TODO L51 Test checkCompatibleType with unions in arg positions of Procedures
    describe('L5 Test checkCompatibleType with unions in arg positions of Procedures', () => {
        // TODO L51
        // Implement the test for the examples given in the document of the assignment (3.2.4)
        it('checks compatibility when procedure types have equal number of parameters, return type of te1 is a subtype of return type of te2, and every parameter type in te2 is a subtype of corresponding parameter type in te1', () => {
            // Define te1 and te2 based on the condition mentioned above
            // Use makeProcTExp to create the procedure types
            const te1 = makeProcTExp([makeNumTExp()], makeStrTExp()); // Example: (number -> string)
            const te2 = makeProcTExp([makeUnionTExp([makeNumTExp(), makeBoolTExp()])], makeStrTExp()); // Example: ((union number boolean) -> string)
            
            // Define an expression based on the procedures above
            const exp = makeProcExp([makeVarDecl('x', makeNumTExp())], [makeStrExp("F OK")], makeStrTExp()); // Example: (lambda ((x : number)) : string "F OK")
            
            // The expected result is Ok(true) because te1 should be compatible with te2 based on the conditions
            const expected = makeOk(true);
    
            // Check the actual result
            const actual = checkCompatibleType(te1, te2, exp);
            
            // The actual result should be the same as expected
            expect(actual).toEqual(expected);
        });
    
    });

    

});
